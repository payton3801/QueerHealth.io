import { ShaderArt } from 'https://cdn.skypack.dev/shader-art';

ShaderArt.register();